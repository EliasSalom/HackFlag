	<div class="footer">© <?php echo date('Y'); ?>  Hackflag . All rights reserved</div>
</div>
<script src="<?php echo e(asset('js/jquery-3.3.1.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/digitalrain.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\hackflag\resources\views/includes/footer.blade.php ENDPATH**/ ?>