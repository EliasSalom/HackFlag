    <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
    <!-- Main Footer -->
    <footer class="main-footer">
        <strong>Copyright &copy; <?php echo date('Y'); ?> .</strong>
        All rights reserved.
        
    </footer>
</div>

<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE -->
<script src="<?php echo e(asset('js/adminlte.js')); ?>"></script>

<!-- OPTIONAL SCRIPTS -->

<script src="<?php echo e(asset('js/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/demo.js')); ?>dist/js/"></script>
<script src="<?php echo e(asset('js/dashboard3.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\hackflag\resources\views/includes/adminfooter.blade.php ENDPATH**/ ?>