<?php
function hackedinfo($parameters){

    //function logic

} 
?>