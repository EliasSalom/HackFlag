<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use App\Url;
use App\User;
use Session;
use DB;

class FrontController extends Controller
{

	public function login()
    {
    	return view('front/login');
    }

    public function register()
    {
    	return view('front/register');
    }

    public function profile()
    {
    	return view('front/profile');
    }

    public function aboutus()
    {
    	return view('front/aboutus');
    }

    public function winner()
    {
    	return view('front/winner');
    }

    public function forgotpassword()
    {
    	return view('front/forgotpassword');
    }

    public function addregister(Request $request)
    {
    	$name = $request->name;
    	$email = $request->email;
    	$password = Hash::make($request->password);
    	$confirmpassword = Hash::make($request->confirmpassword);
    }
}