<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use App\Url;
use App\User;
use Session;
use DB;

class GameController extends Controller
{
	public function index()
	{
		$teacher = session()->get('teacher');
        if(isset($teacher->id) && $teacher->id != '')
        {
        	$get_game_details = DB::table('games')->orderBy('id','desc')->get();
			return view('game/index', compact('get_game_details'));
		}else{
            return redirect('adminlogin');
        }	
	}

	public function addgame()
	{
		$teacher = session()->get('teacher');
        if(isset($teacher->id) && $teacher->id != '')
        {
        	
			return view('game/addgame');
		}else{
            return redirect('adminlogin');
        }
	}

	public function add(Request $request)
	{
		$game_name = $request->game_name;
		$game_description = $request->game_description;
		$game_code = $request->game_code;
		$game_play = $request->game_play;

		$teacher = session()->get('teacher');

		if($request->hasFile('game_image'))
        {
           	$image = $request->file('game_image');
            $name = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = public_path('/game');
            $image->move($destinationPath, $name);
     	}

     	$games =  DB::table('games')->insert(['game_name'=>$game_name,'game_description'=>$game_description,'game_image'=>$name,'game_code'=>$game_code,'status'=>1,'game_play'=>$game_play,'teacher_id'=>$teacher->id,'created'=>NOW(),'updated'=>NOW()]);

	    return redirect()->route('game/index')->with('success', 'Game successfully registered!');
		
	}

	public function gamestatus(Request $request)
	{
		$game_id = $request->game_id;
        $status_id = $request->status_id;

        if($status_id == 0)
            $statusid = $status_id;
        else
            $statusid = $status_id;

        DB::table('games')
        ->where('id', $game_id)
        ->update(['status' => $statusid]);

        echo $statusid;
        die();
	}

	public function deletedgame(Request $request)
	{
		$id = $request->id;

        DB::table('games')->where(['id'=>$id])->delete();
        echo '1';
        die();
	}

	public function editgame($id)
	{
		$teacher = session()->get('teacher');
        if(isset($teacher->id) && $teacher->id != '')
        {
        	$get_game = DB::table('games')->where('id', $id)->first();
			return view('game/editgame', compact('get_game'));
		}else{
            return redirect('adminlogin');
        }
	}

	public function updategame(Request $request)
	{
		$game_name = $request->game_name;
		$game_description = $request->game_description;
		$imageold = $request->imageold;
		$id = $request->id;
		$game_code = $request->game_code;
		$game_play = $request->game_play;

		if($request->hasFile('game_image'))
        {
           	$image = $request->file('game_image');
            $name = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = public_path('/game');
            $image->move($destinationPath, $name);
     	}else{
     		$name = $imageold;
     	}

     	DB::table('games')
        ->where('id', $id)
        ->update(['game_name' => $game_name, 'game_description' => $game_description, 'game_image' => $name, 'game_code' => $game_code, 'game_play' => $game_play, 'updated' => NOW()]);

        return redirect()->route('game/index')->with('success', 'Game successfully updated!');
	}

	public function gamedetails()
	{
		$admin = session()->get('admin');
        if(isset($admin->id) && $admin->id != '')
        {
        	$get_game_details = DB::table('games')->orderBy('id','desc')->get();
			return view('game/gamedetails', compact('get_game_details'));
		}else{
            return redirect('adminlogin');
        }	
	}
}