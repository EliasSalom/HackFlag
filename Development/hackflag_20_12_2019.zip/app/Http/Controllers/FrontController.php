<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use App\Url;
use App\User;
use Session;
use DB;

class FrontController extends Controller
{

	public function login()
    {
    	return view('front/login');
    }

    public function register()
    {
    	return view('front/register');
    }

    public function profile()
    {
        $candidate = session()->get('candidate');
        if(isset($candidate->id) && $candidate->id != '')
        {
    	   return view('front/profile', compact('candidate'));
        }else{
            return redirect('/');
        }
    }

    public function aboutus()
    {
        $candidate = session()->get('candidate');
        $get_cms_about = DB::table('cms')->where(['id'=>1])->first();
    	return view('front/aboutus', compact('candidate','get_cms_about'));
    }

    public function winner()
    {
        $candidate = session()->get('candidate');
        if(isset($candidate->id) && $candidate->id != '')
        {
    	   return view('front/winner', compact('candidate'));
        }else{
            return redirect('/');
        }
    }

    public function forgotpassword()
    {
    	return view('front/forgotpassword');
    }

    public function addregister(Request $request)
    {
        $name = $request->name;
    	$email = $request->email;
    	$password = Hash::make($request->password);
    	$confirmpassword = $request->confirmpassword;
        $type=1;

        $user = DB::table('users')->where(['email'=>$email])->count();

        if($user == 1)
        {
            return redirect()->route('register')->with('error', 'Email already register please use different email id!');
        }else{
            $register =  DB::table('users')->insert(['first_name'=>$name,'email'=>$email,'type'=>$type,'status'=>0,'password'=>$password,'created_at'=>NOW(),'updated_at'=>NOW()]);

            return redirect()->route('login')->with('success', 'Candidate successfully register!');
        }
    }

    public function candidatelogin(Request $request)
    {
        $email = $request->email;
        $password = $request->password;

        if (Auth::attempt(['email' => $email, 'password' => $password]))
        {
            $user = DB::table('users')->where(['email'=>$email])->first();

            if($user->type == 1 && $user->status == 1)
            {
                Session::put('candidate', $user);
                return redirect('profile');
            }else {
                return back()->with('error','Please contact active your account');
            }
        }else{
            return back()->with('error','Please create your account');
        }
    }

    public function logout()
    {
         Session::flush();
        return redirect('/');
    }

    public function sendforgotpassword(Request $request)
    {
        $email = $request->email;

        $users = DB::table('users')->where('email',$email)->count();

        if($users == 1)
        {
            DB::table('users')
            ->where('email', $email)
            ->update(['mail_send' => 0]);
            if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') 
                $link = "https"; 
            else
                $link = "http"; 
              
            // Here append the common URL characters. 
            $link .= "://"; 
            $link .= $_SERVER['HTTP_HOST']; 
            $url = $link."/hackflag/public/newpassword/".base64_encode($email);

            $to = $email;
            $subject = "Forgot Email";

            $message = "
                <html>
                <head>
                <title>Forgot Email</title>
                </head>
                <body>
                <p>Dear ".$email.",</p>
                <p>Click here below the link:- <br/>
                <a href='".$url."'>Click Here</a></p>
                <p>Thanks</p>
                <p>Team Hackflag</p>
                </body>
                </html>";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= 'From: <info@hackflag.com>' . "\r\n";
            mail($to,$subject,$message,$headers);

            return redirect()->route('forgotpassword')->with('success', 'Password successfully sent please check email');
        }else{
            return redirect()->route('forgotpassword')->with('error', 'Incorrect email id please use different mail id');
        }
    }

    public function newpassword($emails)
    {
        $email = base64_decode($emails);
        $user = DB::table('users')->where('email',$email)->first();
        if(isset($user->mail_send) && $user->mail_send == 0)
        {
            return view('front/newpassword', compact('email'));
        }else{
            return redirect()->route('login')->with('error', 'Link has been expired!');
        }

    }

    public function updatemnewpassword(Request $request)
    {
        $newpassword = Hash::make($request->newpassword);
        $email = $request->email;
        $confirmpassword = $request->confirmpassword;
        $mail_send = 1;

        DB::table('users')
        ->where('email', $email)
        ->update(['mail_send' => $mail_send, 'password' => $newpassword]);

        return redirect()->route('login')->with('success', 'Password successfully updated!');
    }

    public function changepassword()
    {
        $candidate = session()->get('candidate');
        if(isset($candidate->id) && $candidate->id != '')
        {
           return view('front/changepassword', compact('candidate'));
        }else{
            return redirect('/');
        }
    }

    public function updatepassword(Request $request)
    {
        $candidate = session()->get('candidate');
        $candidate_id = $candidate->id;
        $currentpassword = $request->currentpassword;
        $newpassword = $request->newpassword;
        $confirmpassword = $request->confirmpassword;

        $candidate_user_password = Auth::user()->password;

        if (!(Hash::check($currentpassword, $candidate_user_password))) 
        {
            return redirect()->back()->with("error","Your current password does not matches with the password you provided. Please try again!");
        }else if(strcmp($currentpassword, $newpassword) == 0){
            return redirect()->back()->with("error","New Password cannot be same as your current password. Please choose a different password!");
        }else{
            DB::table('users')
            ->where('id', $candidate_id)
            ->update(['password' => Hash::make($newpassword)]);
            return redirect()->back()->with("success","Password changed successfully!");
        }
        
    }

    public function gamecode()
    {
        $candidate = session()->get('candidate');
        if(isset($candidate->id) && $candidate->id != '')
        {
           return view('front/gamecode', compact('candidate'));
        }else{
            return redirect('/');
        }
    }

    public function gameplay(Request $request)
    {
        echo '<pre>';
        print_r($request->all()); die();
    }
}