@include('includes.adminheader')
@yield('content')
@include('includes.adminfooter')