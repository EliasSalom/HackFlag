@extends('layouts.front')
@section('content')
<div class="enterboxbg">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="enterbox">
                <div class="logo">
                    <a href="javascript:void(0);">
                        <img src="{{URL::asset('/images/logo.png')}}" alt="Logo" />
                    </a>
                </div>
                <form method="POST" action="{{ route('gameplay') }}" enctype="multipart/form-data" id="myform"  role="form">
                    <div class="gamecodebg">
                        <p class="mb-5">
                            <label>Please Enter Game Code</label>
                            <input type="text" name="game_code" class="gamecodebg-input game_code" id="game_code" value="" />
                        </p>
                        <p>
                            <input type="button" class="joinbtn" value="JOIN The Game" />
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection