	<div class="footer">© <?php echo date('Y'); ?>  Hackflag . All rights reserved</div>
</div>
<script src="{{ asset('js/popper.min.js') }}"></script>
<script src="{{ asset('js/bootstrap.min.js') }}"></script>
<script src="{{ asset('js/digitalrain.js') }}"></script>
</body>
</html>