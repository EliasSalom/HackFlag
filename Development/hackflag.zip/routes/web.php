<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'FrontController@login'); 


Route::get('register', 'FrontController@register')->name('register');
Route::get('profile', 'FrontController@profile')->name('profile');
Route::get('aboutus', 'FrontController@aboutus')->name('aboutus');
Route::get('winner', 'FrontController@winner')->name('winner');
Route::get('forgotpassword', 'FrontController@forgotpassword')->name('forgotpassword');
Route::post('addregister', 'FrontController@addregister')->name('addregister');



//admin start
Route::get('adminlogin', 'AdminController@adminlogin')->name('adminlogin');
Route::post('addlogin', 'AdminController@addlogin')->name('addlogin');
Route::get('admin/dashboard', 'AdminController@dashboard')->name('admin/dashboard');
Route::get('teacher/allteacher', 'TeacherController@allteacher')->name('teacher/allteacher');
Route::get('candidate/candidatedetail', 'CandidateController@candidatedetail')->name('candidate/candidatedetail');
Route::get('teacher/addteacher', 'TeacherController@addteacher')->name('teacher/addteacher');
Route::get('teacher/editteacher/{id}', 'TeacherController@editteacher')->name('teacher/editteacher');
Route::post('insertteacher', 'TeacherController@insertteacher')->name('insertteacher');
Route::post('deletedteachers', 'TeacherController@deletedteachers')->name('deletedteachers');
Route::post('teacherstatus', 'TeacherController@teacherstatus')->name('teacherstatus');
Route::post('teacher/updateteacher', 'TeacherController@updateteacher')->name('teacher/updateteacher');
//end admin


//teacher start
Route::get('teacher/dashboard', 'TeacherController@dashboard')->name('teacher/dashboard');
Route::get('candidate/allcandidate', 'CandidateController@allcandidate')->name('candidate/allcandidate');
Route::get('candidate/addcandidate', 'CandidateController@addcandidate')->name('candidate/addcandidate');
Route::get('candidate/editcandidate/{id}', 'CandidateController@editcandidate')->name('candidate/editcandidate');
Route::post('insertcandidate', 'CandidateController@insertcandidate')->name('insertcandidate');
Route::post('candidatestatus', 'CandidateController@candidatestatus')->name('candidatestatus');
Route::post('deletedcandidate', 'CandidateController@deletedcandidate')->name('deletedcandidate');
Route::post('canidate/updatecandate', 'CandidateController@updatecandate')->name('canidate/updatecandate');
//teacher end



//candidate start

Route::get('admin/logout', 'AdminController@logout')->name('admin/logout');
//end candidate