@extends('layouts.front')
@section('content')
<div class="enterboxbg">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="pagebg">
				<div class="loginform">
					<h1 class="h1color">Login</h1>
					<form>
					  	<div class="form-group">
					    	<label class="labelcolor">Email address</label>
					    	<input type="email" class="form-control" value="">
					  	</div>
					  	<div class="form-group">
					    	<label class="labelcolor">Password</label>
					    	<input type="password" class="form-control" value="">
					  	</div>
					  	<div class="form-group">
					  		<input type="submit" class="joinbtn" value="login">
					  	</div>
					  	<div class="form-group forgotpass">
					  		<a class="registereclass" href="{{ url('register') }}">Register</a>
					  		<a href="{{ url('forgotpassword') }}">Forgot Password?</a>
					  	</div>					  	

					  	
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection