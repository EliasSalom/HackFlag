@include('includes.teacherheader')
@yield('content')
@include('includes.teacherfooter')